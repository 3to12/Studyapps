# main/migrations/0002_populate_apps.py
from django.db import migrations

def add_initial_apps(apps, schema_editor):
    ExternalApp = apps.get_model('main', 'ExternalApp')
    apps_data = [
        ('VB', 'https://vocabbrain.com', 'fa-brain', '#FF6B6B'),
        ('SW', 'https://studentswriting.com', 'fa-pencil-alt', '#4ECDC4'),
        ('RK', 'https://readingknack.com', 'fa-book-open', '#FFD166'),
        ('MM', 'https://mymath.com', 'fa-square-root-alt', '#6B5B95'),
        ('HH', 'https://historyapp.com', 'fa-landmark', '#FF9F1C'),
        ('SV', 'https://stemvault.com', 'fa-atom', '#2EC4B6'),
        ('NS', 'https://nextgenscience.com', 'fa-flask', '#E71D36'),
        ('GN', 'https://goodnews.com', 'fa-newspaper', '#011627')
    ]
    
    for code, url, icon, color in apps_data:
        ExternalApp.objects.create(
            app_code=code,
            base_url=url,
            icon_class=icon,
            color_code=color
        )

class Migration(migrations.Migration):
    dependencies = [
        ('main', '0001_initial'),  # This links to your first migration
    ]

    operations = [
        migrations.RunPython(add_initial_apps),
    ]