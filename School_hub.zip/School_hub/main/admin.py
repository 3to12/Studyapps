# admin.py
from django.contrib import admin
from .models import Branch, CustomUser
from django.contrib.auth.admin import UserAdmin
from .models import ExternalApp

@admin.register(Branch)
class BranchAdmin(admin.ModelAdmin):
    list_display = ['name', 'address']

    
@admin.register(CustomUser)
class CustomUserAdmin(admin.ModelAdmin):
    list_display = ['username', 'role', 'branch']

    def get_queryset(self, request):
        qs = super().get_queryset(request)
        # Allow superusers to see all branches
        if request.user.is_superuser:
            return qs
        # Restrict other users to only see their own branch
        return qs.filter(branch=request.user.branch)



@admin.register(ExternalApp)
class ExternalAppAdmin(admin.ModelAdmin):
    list_display = ('get_app_code_display', 'base_url')
    search_fields = ('app_code',)