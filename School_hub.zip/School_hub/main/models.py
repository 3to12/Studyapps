from django.db import models
from django.contrib.auth.models import AbstractUser

class Branch(models.Model):
    name = models.CharField(max_length=100)
    address = models.CharField(max_length=255, blank=True, null=True)
    
    def __str__(self):
        return self.name

class CustomUser(AbstractUser):
    ROLE_CHOICES = [
        ('branch director', 'Branch Director'),
        ('admin', 'Admin'),
        ('teacher', 'Teacher'),
        ('parent', 'Parent')
    ]
    role = models.CharField(max_length=20, choices=ROLE_CHOICES, default='parent')
    branch = models.ForeignKey(Branch, on_delete=models.CASCADE, null=True, blank=True)
    is_active = models.BooleanField(default=True)

    def save(self, *args, **kwargs):
        # Ensure superusers are always given 'branch director' role and staff status
        if self.is_superuser:
            self.role = 'branch director'
            self.is_staff = True
        elif self.role in ['admin', 'branch director']:
            self.is_staff = True
        else:
            self.is_staff = False
        super(CustomUser, self).save(*args, **kwargs)

class ExternalApp(models.Model):
    APP_CHOICES = [
        ('VB', 'VocabBrain'),
        ('SW', 'Students Writing'),
        ('RK', 'Reading Knack'),
        ('MM', 'MyMath'),
        ('HH', 'His & Herstory'),
        ('SV', 'STEMvault'),
        ('NS', 'NextGen Science'),
        ('GN', 'Good News')
    ]
    
    app_code = models.CharField(max_length=2, choices=APP_CHOICES, unique=True)
    base_url = models.URLField()
    icon_class = models.CharField(max_length=30)  # Font Awesome class
    color_code = models.CharField(max_length=7)   # Hex color

    def __str__(self):
        return self.get_app_code_display()