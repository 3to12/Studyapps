from django.contrib.auth import login
from django.contrib.auth.forms import AuthenticationForm
from django.shortcuts import redirect, render

from main.models import ExternalApp
from .forms import SignUpForm
from .forms import BranchForm
from django.contrib.auth.decorators import user_passes_test
from django.contrib.auth.decorators import login_required


def login_view(request):
    if request.method == 'POST':
        login_form = AuthenticationForm(request, data=request.POST)
        if login_form.is_valid():
            user = login_form.get_user()
            login(request, user)
            next_url = request.GET.get('next', 'index') 
            return redirect(next_url)
    else:
        login_form = AuthenticationForm()

    return render(request, 'main/login.html', {'login_form': login_form})

def signup_view(request):
    if request.method == 'POST':
        signup_form = SignUpForm(request.POST)
        if signup_form.is_valid():
            user = signup_form.save(commit=False)
            user.set_password(signup_form.cleaned_data['password'])
            user.save()
            login(request, user)
            return redirect('index')
    else:
        signup_form = SignUpForm()

    return render(request, 'main/signup.html', {'signup_form': signup_form})

def get_user_role(user):
    if user.is_superuser:
        return 'admin'
    elif user.groups.filter(name='Teachers').exists():
        return 'teacher'
    elif user.groups.filter(name='Parents').exists():
        return 'parent'
    else:
        return 'unknown'

@login_required
def index(request):
    context = {
        'external_apps': ExternalApp.objects.all(),
        'user_role': request.user.role,
        'user_branch': request.user.branch,
    }
    return render(request, 'main/index.html', context)

def is_admin(user):
    return user.is_superuser or user.role in ['admin', 'branch director']

@user_passes_test(is_admin)
def create_branch(request):
    if request.method == 'POST':
        form = BranchForm(request.POST)
        if form.is_valid():
            branch = form.save()
            request.user.branch = branch
            request.user.save()
            return redirect('index') 
    else:
        form = BranchForm()
    return render(request, 'main/create_branch.html', {'form': form})